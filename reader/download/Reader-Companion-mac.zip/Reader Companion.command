#!/bin/sh
# Reader Companion: double-click to set this Mac up for the reader at https://saurav717.github.io/reader/
# (the Companion, the VS Code extension, and starting it at every login).
cd "$HOME" || exit 1
curl -LsSf https://saurav717.github.io/reader/companion-setup.sh | sh
echo
printf 'Press Return to close this window. '
read -r _
